---
name: Question
about: Describe your questions in details
title: "[Question] your title here"
labels: question
assignees: ashvayka

---

**Component**

<!-- Choose one of the following and delete all others. -->
 * UI
 * Rule Engine
 * Installation
 * Generic

**Description**
A clear and concise details.

**Environment**
<!-- Add information about your environment and ThingsBoard version if applicable -->
 * OS:  name and version
 * ThingsBoard: version
 * Browser: name and version
